# @suno2daw/suno-core

Núcleo común de Suno, **fuente canónica** de suno2daw, la extensión de Chrome (`suno-stems-extension`),
`suno-api` y Trackroom (a través de `suno-api`). Sin DOM, cookies, fs, red ni dependencias. Web Crypto inyectable (navegador o Node).

| Export | Qué hace |
|---|---|
| `describeClip(clip)` | `{ isStem, isComplement, stemName, songTitle, version, kind, songId, userId, handle }`. Complemento por `metadata.stem_task === 'remove'` o título «Without X»; `songId` salta el UUID nulo y mira `history[0]`. |
| `createPlaybackCrypto({ subtle })` | `deriveMasterKey(token)` (SHA-256), `unwrapKey` / `unwrapPlaybackRights` (AES-GCM, AAD = clipId), `decryptPlayback` (AES-CTR 128 bits + validación MP4 y longitud de clave). |
| `selectPlaybackUrl(clip, { clipId, allowLegacyCdn })` | URL `progressive` + `1.0.0` de `media_urls`, con política https / `*.cloudfront.net` / sin puerto ni credenciales / id en la ruta. El CDN antiguo solo si el clip **no trae** `media_urls` y se pide `allowLegacyCdn: true`. |
| `isClipId`, `bytesToHex`, `hexToBytes`, `base64ToBytes`, `isMp4`, `SunoCoreError`… | Utilidades. Errores con mensaje fijo y `code`; nunca incluyen token, claves ni valores envueltos. |

El token no se guarda en estado de módulo: quien llama lo pasa a `deriveMasterKey` y conserva la
`C## Versiones y distribución

Es una librería versionada: nadie copia su código. Cada repo depende de un `.tgz` con versión fija,
igual que `@naz4ri/lyrics-sync`.

```
npm run pack:release        # build (dist/suno-core.global.js) + npm pack → suno2daw-suno-core-X.Y.Z.tgz
```

| Consumidor | Cómo la usa |
|---|---|
| suno2daw | workspace (`packages/suno-core`), siempre la fuente |
| suno-api | `"@suno2daw/suno-core": "file:vendor/suno2daw-suno-core-X.Y.Z.tgz"` · `import { … } from '@suno2daw/suno-core'` |
| suno-stems-extension | misma dependencia; `scripts/build.sh` copia `@suno2daw/suno-core/global` (MAIN world, `globalThis.__sunoCore`) |
| Trackroom | no la incluye: pide el audio a suno-api (`/api/playback_audio`) |

Para publicar un cambio: sube `version` en `package.json`, `npm run pack:release`, copia el `.tgz` al
`vendor/` de cada consumidor, cambia la versión en su `package.json` y `npm install`.

 y haz commit de las copias en cada repo.

## Tests

```
npm test    # node --test "test/*.test.js"
```

Round-trip con token inventado y MP4 sintético (servidor simulado con `node:crypto`), rechazos por
token/AAD/clave incorrectos, `describeClip` con la captura real
`research/fixtures/advanced-drums-submitted.json`, URLs inválidas y drift del distribuidor.
